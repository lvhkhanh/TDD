Hi C# Developer,

This module continues where the previous module ended. Look in the "after" folder of the previous module to grab the starter solution for this module.

Thank you,
Thomas Claudius Huber
www.thomasclaudiushuber.com