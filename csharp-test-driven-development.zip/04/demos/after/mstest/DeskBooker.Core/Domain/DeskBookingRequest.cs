﻿namespace DeskBooker.Core.Domain
{
  public class DeskBookingRequest : DeskBookingBase
  {

  }
}