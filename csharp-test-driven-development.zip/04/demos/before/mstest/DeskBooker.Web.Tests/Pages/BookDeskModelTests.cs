﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DeskBooker.Web.Pages
{
  [TestClass]
  public class BookDeskModelTests
  {

  }
}
