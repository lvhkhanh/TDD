﻿namespace DeskBooker.Web.Pages
{
  public class BookDeskModelTests
  {

  }
}
