﻿using NUnit.Framework;

namespace DeskBooker.Web.Pages
{
  [TestFixture]
  public class BookDeskModelTests
  {

  }
}
