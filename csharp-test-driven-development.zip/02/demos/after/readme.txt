Hi C# Developer,

Test Driven Development is an approach that works with any testing framework. 

When you watch this course, you'll see that I'm using xUnit to write the tests. 

But in this folder you find the exercise files not only for xUnit, but also for the popular and widely used testing frameworks NUnit and MSTest.

So, I hope you find your favorite .NET testing framework here.

Thank you,
Thomas Claudius Huber
www.thomasclaudiushuber.com