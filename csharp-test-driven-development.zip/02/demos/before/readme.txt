Hi C# Developer,

In this first module, a new solution was created, so there's nothing in this "before" folder. Look in the "after" folder to see what was created in this module.

Thank you,
Thomas Claudius Huber
www.thomasclaudiushuber.com