﻿namespace DeskBooker.Core.Domain
{
  public class Desk
  {
    public int Id { get; set; }
  }
}